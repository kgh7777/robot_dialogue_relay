"""
grounding_check.py (v2 — unit-value pair 기반)

모델이 인용한 수치가 입력 텔레메트리 벡터의 값과 "단위까지 맞게" 일치하는지 검사.

v1 대비 개선점:
  1) 숫자만 비교하지 않고 (unit, value) 쌍으로 비교한다.
     -> 온도값과 전력값이 우연히 같은 숫자라도 단위가 다르면 다른 값으로 취급.
     -> "온도와 전력을 서로 바꿔 말하는" 스왑 오류를 잡아낼 수 있다.
  2) 존재 여부(bool)가 아니라 등장 횟수(Counter, 멀티셋)로 비교한다.
     -> 카드 두 개가 우연히 같은 값이어도, 모델이 한 번만 언급하면
        "하나만 커버됨"으로 정확히 잡힌다.
  3) 디바이스 인덱스 예외처리를 "card 뒤에 붙는 숫자"로 좁힌다.
     -> U:2.0% 같은 진짜 측정값이 "0~3이니까 인덱스"로 오분류되어
        환각 검사에서 부당하게 빠지는 것을 방지.

원리:
  - 입력 벡터에서 카드별 (unit, value) 쌍을 모두 추출 (NA 제외)
  - 모델 출력(한국어/영어)에서도 "숫자+단위가 붙어 있는" 쌍만 추출
    (단위 없이 등장하는 숫자는 애초에 "인용"이라 보기 어려우므로 별도 카운트)
  - 입력의 모든 (unit, value)가 KO·EN 양쪽에 등장 횟수까지 맞게 나오면 그라운딩 성공
  - 입력에 없는 (unit, value)가 출력에 등장하면 환각
"""

from __future__ import annotations

import logging
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Iterable

import gpu_telemetry as gt

log = logging.getLogger("grounding_check")

# ---------------------------------------------------------------------------
# 입력 벡터 파싱
# ---------------------------------------------------------------------------

# 예: [card0 T:44.0C,P:186.0W,V:10240.0MiB,U:62.0%]
# NA 값도 매칭해야 한다 (예: T:NAC, P:NAW, V:NAMiB, U:NA%)
_VECTOR_RE = re.compile(
    r"\[(?P<name>\S+)\s+"
    r"T:(?P<T>[\d.]+|NA)C,"
    r"P:(?P<P>[\d.]+|NA)W,"
    r"V:(?P<V>[\d.]+|NA)MiB,"
    r"U:(?P<U>[\d.]+|NA)%\]"
)

_NA_MARKER_RE = re.compile(r"^NA$")

# 필드 이름(T/P/V/U) -> 실제 단위 문자열 매핑
_FIELD_UNIT = {
    "T": "C",
    "P": "W",
    "V": "MiB",
    "U": "%",
}


@dataclass(frozen=True)
class UnitValue:
    """(단위, 정규화된 값) 쌍. 예: ("C", "44.0")"""
    unit: str
    value: str

    def __str__(self) -> str:
        return f"{self.value}{self.unit}"


@dataclass
class VectorNumber:
    """입력 벡터에서 추출한 (카드, 필드, 값) 한 개."""
    card: str
    field: str
    raw: str  # 원문 (예: "44.0")
    is_na: bool

    @property
    def unit(self) -> str:
        return _FIELD_UNIT[self.field]


def parse_vector(vector_str: str) -> list[VectorNumber]:
    """
    텔레메트리 벡터 문자열에서 모든 (card, field, value) 추출.
    NA 마커는 is_na=True로 표시 (검사 제외 대상).
    """
    out: list[VectorNumber] = []
    for m in _VECTOR_RE.finditer(vector_str):
        name = m.group("name")
        for field_name in ("T", "P", "V", "U"):
            raw = m.group(field_name)
            out.append(VectorNumber(
                card=name, field=field_name, raw=raw,
                is_na=_NA_MARKER_RE.match(raw) is not None,
            ))
    return out


# ---------------------------------------------------------------------------
# 모델 출력에서 "단위가 붙은" 수치 추출
# ---------------------------------------------------------------------------

# 숫자 뒤에 단위가 바로 붙거나(44.0C), 공백 하나를 두고 붙는 경우(44.0 C)까지 허용.
# 단위는 길이가 겹치는 문제를 피하려고 긴 것부터 매칭 (MiB > W/C/%).
# %의 경우 앞에 공백이 없는 게 일반적이라 별도 처리.
_UNIT_PATTERN = r"(?:MiB|°C|C|W|%)"
# 주의: 여기서 \b(단어 경계)를 쓰면 안 된다. 한국어 조사가 단위 뒤에 바로 붙으면
# ("44.0C이고", "62.0%입니다") 파이썬 re는 한글도 \w로 취급하기 때문에
# C/이, %/입 사이에 경계가 생기지 않아 매칭이 실패한다.
# 대신 "단위 뒤에 또 다른 라틴 알파벳이 곧바로 이어지는 경우만" 배제한다.
# (예: "44.0Cat" 같은 오탐은 막고, "44.0C이고"는 정상 매칭되도록)
_NUM_UNIT_RE = re.compile(
    r"(?P<num>\d+(?:\.\d+)?)\s*(?P<unit>" + _UNIT_PATTERN + r")(?![A-Za-z])"
)

# 단위 표기 정규화: °C -> C
_UNIT_NORM = {
    "°C": "C",
    "C": "C",
    "W": "W",
    "MiB": "MiB",
    "%": "%",
}

# 카드 이름(card0, device1 등) 뒤에 바로 붙는 숫자는 디바이스 인덱스로 간주하고
# "단위 없는 숫자" 집계에서도 제외한다. (예: "card0", "device 1")
_CARD_INDEX_RE = re.compile(r"(?:card|device)\s*(\d+)", re.IGNORECASE)


def extract_unit_values(text: str) -> Counter:
    """
    텍스트에서 (unit, normalized_value) 쌍을 모두 추출해 Counter로 반환.
    "44.0C", "186.0 W", "10240MiB", "62%" 등을 인식.
    """
    counter: Counter = Counter()
    for m in _NUM_UNIT_RE.finditer(text):
        num = _norm(m.group("num"))
        unit = _UNIT_NORM.get(m.group("unit"), m.group("unit"))
        counter[UnitValue(unit=unit, value=num)] += 1
    return counter


def extract_bare_numbers(text: str) -> Counter:
    """
    단위가 붙지 않은 숫자들만 추출 (카드/디바이스 인덱스로 보이는 숫자는 제외).
    이건 "환각인지 아닌지 확신할 수 없는" 참고용 집계로만 쓴다.
    """
    card_indices = {m.group(1) for m in _CARD_INDEX_RE.finditer(text)}

    # 단위가 붙은 부분은 이미 extract_unit_values에서 처리했으니,
    # 그 구간은 제외하고 나머지 숫자만 찾는다.
    unit_spans = [m.span() for m in _NUM_UNIT_RE.finditer(text)]

    def _in_unit_span(pos: int) -> bool:
        return any(s <= pos < e for s, e in unit_spans)

    counter: Counter = Counter()
    for m in re.finditer(r"\d+(?:\.\d+)?", text):
        if _in_unit_span(m.start()):
            continue
        if m.group(0) in card_indices:
            continue
        counter[_norm(m.group(0))] += 1
    return counter


# ---------------------------------------------------------------------------
# 정규화
# ---------------------------------------------------------------------------

def _norm(s: str) -> str:
    """수치 문자열 정규화: '44.0'/'44'/'44.00' 모두 '44.0'으로 비교."""
    try:
        f = float(s)
        if f.is_integer():
            return f"{f:.1f}"
        return f"{f:g}"
    except ValueError:
        return s


# ---------------------------------------------------------------------------
# 검사 결과
# ---------------------------------------------------------------------------

@dataclass
class CheckResult:
    vector_input: str
    ko_sentence: str
    en_sentence: str

    n_total: int = 0                 # 입력에 있던 NA가 아닌 (unit,value) 총 개수
    n_covered_ko: int = 0            # KO에서 등장 횟수까지 맞게 커버된 개수
    n_covered_en: int = 0
    n_covered_both: int = 0

    missing_values: list[str] = field(default_factory=list)          # 미등장/부족
    hallucinated_ko: list[str] = field(default_factory=list)         # (unit,value) 환각
    hallucinated_en: list[str] = field(default_factory=list)
    bare_number_hits_ko: list[str] = field(default_factory=list)     # 단위 없이 등장한 숫자 (참고용)
    bare_number_hits_en: list[str] = field(default_factory=list)

    @property
    def ko_coverage(self) -> float:
        return (self.n_covered_ko / self.n_total) if self.n_total else 0.0

    @property
    def en_coverage(self) -> float:
        return (self.n_covered_en / self.n_total) if self.n_total else 0.0

    @property
    def both_coverage(self) -> float:
        return (self.n_covered_both / self.n_total) if self.n_total else 0.0

    @property
    def is_checkable(self) -> bool:
        return self.n_total > 0

    @property
    def is_grounded(self) -> bool:
        """
        그라운딩 성공 = NA가 아닌 모든 입력 (unit,value)가
        KO·EN 양쪽에서 등장 횟수까지 정확히 커버되고, 환각이 하나도 없을 때.
        (v1과 달리 환각이 있으면 자동으로 실패 처리한다 — 값이 다 나왔어도
         엉뚱한 값을 추가로 지어냈다면 그라운딩이 완전하다고 볼 수 없다.)
        """
        return (
            self.n_total > 0
            and self.n_covered_both == self.n_total
            and not self.hallucinated_ko
            and not self.hallucinated_en
        )

    def summary(self) -> str:
        checkable = "✓" if self.is_checkable else "✗ (검사 무효)"
        grounded = "✓" if self.is_grounded else "✗"
        return (
            f"그라운딩 검사 결과 (unit-value 기반)\n"
            f"  입력 (unit,value)(NA 제외): {self.n_total}개 (검사 가능: {checkable})\n"
            f"  KO 커버: {self.n_covered_ko} ({self.ko_coverage*100:.1f}%)\n"
            f"  EN 커버: {self.n_covered_en} ({self.en_coverage*100:.1f}%)\n"
            f"  KO·EN 모두 커버: {self.n_covered_both} ({self.both_coverage*100:.1f}%)\n"
            f"  미등장/부족: {self.missing_values}\n"
            f"  KO 환각 (unit,value): {self.hallucinated_ko}\n"
            f"  EN 환각 (unit,value): {self.hallucinated_en}\n"
            f"  KO 단위없는 숫자(참고용): {self.bare_number_hits_ko}\n"
            f"  EN 단위없는 숫자(참고용): {self.bare_number_hits_en}\n"
            f"  그라운딩 성공 여부: {grounded}\n"
        )


# ---------------------------------------------------------------------------
# 메인 검사 함수
# ---------------------------------------------------------------------------

def check_grounding(
    vector_input: str,
    ko_sentence: str,
    en_sentence: str,
) -> CheckResult:
    inputs = parse_vector(vector_input)
    non_na = [v for v in inputs if not v.is_na]

    # 입력 쪽 (unit,value) 멀티셋. 카드가 달라도 값+단위가 같으면 같은 키로 합산된다.
    # -> "카드 두 개가 같은 값"인 경우, 모델이 그 값을 두 번 언급해야 완전 커버.
    input_counter: Counter = Counter()
    for v in non_na:
        input_counter[UnitValue(unit=v.unit, value=_norm(v.raw))] += 1

    ko_counter = extract_unit_values(ko_sentence)
    en_counter = extract_unit_values(en_sentence)

    ko_bare = extract_bare_numbers(ko_sentence)
    en_bare = extract_bare_numbers(en_sentence)

    n_total = sum(input_counter.values())

    # 커버리지: min(입력 개수, 출력 개수)의 총합 (등장 횟수까지 반영)
    n_covered_ko = sum(min(cnt, ko_counter.get(uv, 0)) for uv, cnt in input_counter.items())
    n_covered_en = sum(min(cnt, en_counter.get(uv, 0)) for uv, cnt in input_counter.items())
    n_covered_both = sum(
        min(cnt, ko_counter.get(uv, 0), en_counter.get(uv, 0))
        for uv, cnt in input_counter.items()
    )

    # 부족/미등장 상세
    missing: list[str] = []
    for uv, cnt in input_counter.items():
        got_ko = ko_counter.get(uv, 0)
        got_en = en_counter.get(uv, 0)
        if got_ko < cnt or got_en < cnt:
            missing.append(f"{uv} (필요 {cnt}회, KO {got_ko}회, EN {got_en}회)")

    # 환각: 출력에 있는데 입력에 없는 (unit,value), 또는 입력보다 더 많이 등장한 초과분
    def _hallucinated(out_counter: Counter) -> list[str]:
        result = []
        for uv, cnt in out_counter.items():
            excess = cnt - input_counter.get(uv, 0)
            if excess > 0:
                result.append(f"{uv} (x{excess} 초과/미존재)")
        return result

    hallu_ko = _hallucinated(ko_counter)
    hallu_en = _hallucinated(en_counter)

    return CheckResult(
        vector_input=vector_input,
        ko_sentence=ko_sentence,
        en_sentence=en_sentence,
        n_total=n_total,
        n_covered_ko=n_covered_ko,
        n_covered_en=n_covered_en,
        n_covered_both=n_covered_both,
        missing_values=missing,
        hallucinated_ko=hallu_ko,
        hallucinated_en=hallu_en,
        bare_number_hits_ko=[f"{k}(x{v})" for k, v in ko_bare.items()],
        bare_number_hits_en=[f"{k}(x{v})" for k, v in en_bare.items()],
    )


# ---------------------------------------------------------------------------
# CLI 진입점
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json
    import sys

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    if len(sys.argv) < 2:
        samples = gt.collect()
        vec = gt.to_vector_string(samples)
        print(f"[demo] vector = {vec}")
        result = check_grounding(vec, ko_sentence="", en_sentence="")
        print(result.summary())
    else:
        payload = json.loads(sys.stdin.read())
        result = check_grounding(
            payload["vector"],
            ko_sentence=payload.get("ko", ""),
            en_sentence=payload.get("en", ""),
        )
        print(result.summary())
