"""
relay_dialogue.py

Qwen <-> Llama3.3 영어 발화 릴레이.

구조 (벌의 8자 춤과 동일한 신호-해석-확인 구조, 행동 트리거는 이 파일의 범위 밖):

  1. rocm-smi에서 device0 온도 추출 (gpu_telemetry.collect, LLM 없음, 결정적)
  2. Qwen이 그 수치를 바탕으로 영어 한 문장 발화 생성
       - 온도가 임계치 이상이면 지시문(directive):
         "The temperature is 46.0C, which is high. Return to base."
       - 아니면 평서문(declarative):
         "The temperature is 40.0C, which is normal."
  3. 그 문장을 Llama3.3에게 그대로 전달 -> Llama3.3이 해석하고 응답 문장 생성
       (예: "OK, I will move quickly." 또는 "Understood, no action needed.")
  4. Llama3.3의 응답을 다시 Qwen에게 전달 -> Qwen이 확인 문장 생성
       (예: "Acknowledged.")

이 파일은 "행동을 유발할 수 있는 언어"의 구조(지시-해석-확인)를 검증하는 데
목적이 있고, 실제 모터 구동이나 안전 판단과는 분리되어 있다 — 안전 반사는
여전히 별도의 결정적 코드(safety_node)가 담당해야 한다.

매 발화마다 grounding_check의 (unit,value) 추출 로직을 재사용해,
원래 측정값(온도 C) 외의 숫자가 지어내지지 않았는지 자동 검사한다.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import requests

import gpu_telemetry as gt
from grounding_check import extract_unit_values, UnitValue, _norm

log = logging.getLogger("relay_dialogue")

# ---------------------------------------------------------------------------
# 설정
# ---------------------------------------------------------------------------

QWEN_URL = os.environ.get("QWEN_URL", "http://localhost:2242/v1/chat/completions")
QWEN_MODEL = os.environ.get("QWEN_MODEL", "qwen2.5-32b-instruct-q4_k_m")

LLAMA33_URL = os.environ.get("LLAMA33_URL", "http://localhost:11434/v1/chat/completions")
LLAMA33_MODEL = os.environ.get("LLAMA33_MODEL", "llama3.3")

DEFAULT_TIMEOUT = (5, 60)
DEFAULT_TEMP_THRESHOLD_C = 45.0


# ---------------------------------------------------------------------------
# 프롬프트
# ---------------------------------------------------------------------------

QWEN_UTTER_SYSTEM = (
    "You report GPU temperature readings in exactly one English sentence.\n"
    "Rules:\n"
    "  (1) Quote the temperature value and unit (C) exactly as given. Never invent numbers.\n"
    "  (2) If the temperature is at or above the given threshold, phrase it as a directive "
    "ending with an instruction to return to base (e.g. \"... which is high. Return to base.\").\n"
    "  (3) If below the threshold, phrase it as a plain statement that operation is normal.\n"
    "  (4) Output exactly one sentence. No preamble, no explanation, no extra text.\n"
)

QWEN_UTTER_USER_TEMPLATE = (
    "Measured temperature: {temp:.1f}C. Threshold: {threshold:.1f}C. "
    "Produce the single sentence now."
)

LLAMA_RESPOND_SYSTEM = (
    "You are a second robot receiving a message from another robot.\n"
    "Rules:\n"
    "  (1) Respond in exactly one short English sentence acknowledging the message.\n"
    "  (2) If the message is a directive (an instruction to act), acknowledge it and state "
    "the action you will take (e.g. \"OK, I will move quickly.\").\n"
    "  (3) If the message is only a statement (no instruction), acknowledge it without "
    "claiming any action (e.g. \"Understood, no action needed.\").\n"
    "  (4) Never invent or repeat numeric values that were not in the message. If you must "
    "refer to the reading, refer to it only in words, not with a new number.\n"
    "  (5) Output exactly one sentence. No preamble, no explanation.\n"
)

QWEN_ACK_SYSTEM = (
    "You are the first robot. You already sent a message and received a reply.\n"
    "Rules:\n"
    "  (1) Respond in exactly one short English sentence acknowledging the reply.\n"
    "  (2) Do not invent any new numeric values.\n"
    "  (3) Output exactly one sentence. No preamble, no explanation.\n"
)


# ---------------------------------------------------------------------------
# 결과 컨테이너
# ---------------------------------------------------------------------------

@dataclass
class DialogueTurn:
    speaker: str            # "qwen_utterance" | "llama33_response" | "qwen_ack"
    model: str
    content: str
    latency_sec: float
    http_status: int
    error: str = ""
    hallucinated: list[str] = field(default_factory=list)  # 원 측정값 외 숫자(unit 포함)

    def to_dict(self) -> dict:
        return {
            "speaker": self.speaker,
            "model": self.model,
            "content": self.content,
            "latency_sec": round(self.latency_sec, 3),
            "http_status": self.http_status,
            "error": self.error,
            "hallucinated": self.hallucinated,
        }


@dataclass
class DialogueExchange:
    temperature_c: Optional[float]
    threshold_c: float
    turns: list[DialogueTurn] = field(default_factory=list)

    @property
    def is_clean(self) -> bool:
        """모든 턴에서 환각(원 측정값 외 숫자)이 하나도 없었는가."""
        return all(not t.hallucinated for t in self.turns) and all(
            not t.error for t in self.turns
        )

    def to_dict(self) -> dict:
        return {
            "temperature_c": self.temperature_c,
            "threshold_c": self.threshold_c,
            "turns": [t.to_dict() for t in self.turns],
            "is_clean": self.is_clean,
        }

    def summary(self) -> str:
        lines = [f"=== 대화 교환 (온도={self.temperature_c}, 임계치={self.threshold_c}) ==="]
        for t in self.turns:
            tag = "OK" if not t.error and not t.hallucinated else "FAIL"
            lines.append(f"  [{tag}] {t.speaker} ({t.model}, {t.latency_sec:.1f}s): {t.content}")
            if t.hallucinated:
                lines.append(f"        환각 의심: {t.hallucinated}")
            if t.error:
                lines.append(f"        에러: {t.error}")
        lines.append(f"  전체 결과: {'CLEAN (환각/에러 없음)' if self.is_clean else 'ISSUE 있음'}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# 공통 LLM 호출 헬퍼
# ---------------------------------------------------------------------------

def _call_llm(
    url: str,
    model: str,
    system_prompt: str,
    user_content: str,
    *,
    temperature: float = 0.0,
    max_tokens: int = 100,
    timeout=DEFAULT_TIMEOUT,
) -> tuple[str, float, int, str]:
    """
    returns: (content, latency_sec, http_status, error)
    content/http_status는 실패 시 "" / 0.
    """
    payload = {
        "model": model,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
    }

    t0 = time.monotonic()
    try:
        r = requests.post(url, json=payload, timeout=timeout)
    except requests.RequestException as e:
        return "", time.monotonic() - t0, 0, str(e)
    latency = time.monotonic() - t0

    if r.status_code != 200:
        return "", latency, r.status_code, f"HTTP {r.status_code}"

    try:
        data = r.json()
        content = data["choices"][0]["message"]["content"].strip()
    except (ValueError, KeyError, IndexError) as e:
        return "", latency, r.status_code, f"bad response shape: {e}"

    return content, latency, r.status_code, ""


def _check_numeric_fidelity(content: str, expected_temp: Optional[float]) -> list[str]:
    """
    content에서 단위(C/W/MiB/%)가 붙은 (unit,value)를 뽑아,
    expected_temp(섭씨) 외의 값이 있으면 환각으로 표시.
    expected_temp가 None이면 어떤 수치 인용도 검증할 근거가 없다는 뜻이므로
    빈 리스트를 반환한다 (검증 불가로 통과 처리).
    """
    if expected_temp is None:
        return []
    expected = UnitValue(unit="C", value=_norm(f"{expected_temp:.1f}"))
    found = extract_unit_values(content)
    hallucinated = [str(uv) for uv in found.keys() if uv != expected]
    return hallucinated


# ---------------------------------------------------------------------------
# 핵심 흐름: 온도 추출 -> Qwen 발화 -> Llama3.3 응답 -> Qwen 확인
# ---------------------------------------------------------------------------

def run_dialogue(
    *,
    device_index: int = 0,
    threshold_c: float = DEFAULT_TEMP_THRESHOLD_C,
    qwen_url: str = QWEN_URL,
    qwen_model: str = QWEN_MODEL,
    llama33_url: str = LLAMA33_URL,
    llama33_model: str = LLAMA33_MODEL,
    timeout=DEFAULT_TIMEOUT,
) -> DialogueExchange:
    # 1) 실측 온도 추출 (LLM 없음)
    samples = gt.collect(target_indices=(device_index,))
    temp = samples[0].temperature_c if samples else None

    exchange = DialogueExchange(temperature_c=temp, threshold_c=threshold_c)

    if temp is None:
        log.warning("device%d 온도를 읽지 못했습니다 (NA). 대화를 생략합니다.", device_index)
        return exchange

    # 2) Qwen 발화 생성
    user_msg_1 = QWEN_UTTER_USER_TEMPLATE.format(temp=temp, threshold=threshold_c)
    content1, lat1, status1, err1 = _call_llm(
        qwen_url, qwen_model, QWEN_UTTER_SYSTEM, user_msg_1, timeout=timeout
    )
    turn1 = DialogueTurn(
        speaker="qwen_utterance", model=qwen_model, content=content1,
        latency_sec=lat1, http_status=status1, error=err1,
        hallucinated=_check_numeric_fidelity(content1, temp),
    )
    exchange.turns.append(turn1)
    if err1:
        log.error("Qwen 발화 실패: %s", err1)
        return exchange

    # 3) Llama3.3이 그 발화를 받아 응답
    content2, lat2, status2, err2 = _call_llm(
        llama33_url, llama33_model, LLAMA_RESPOND_SYSTEM, content1, timeout=timeout
    )
    turn2 = DialogueTurn(
        speaker="llama33_response", model=llama33_model, content=content2,
        latency_sec=lat2, http_status=status2, error=err2,
        hallucinated=_check_numeric_fidelity(content2, temp),
    )
    exchange.turns.append(turn2)
    if err2:
        log.error("Llama3.3 응답 실패: %s", err2)
        return exchange

    # 4) Qwen이 Llama3.3의 응답을 받아 확인
    content3, lat3, status3, err3 = _call_llm(
        qwen_url, qwen_model, QWEN_ACK_SYSTEM, content2, timeout=timeout
    )
    turn3 = DialogueTurn(
        speaker="qwen_ack", model=qwen_model, content=content3,
        latency_sec=lat3, http_status=status3, error=err3,
        hallucinated=_check_numeric_fidelity(content3, temp),
    )
    exchange.turns.append(turn3)
    if err3:
        log.error("Qwen 확인 실패: %s", err3)

    return exchange


# ---------------------------------------------------------------------------
# 대량 반복 (신뢰성 확인용)
# ---------------------------------------------------------------------------

def run_dialogue_batch(n: int, **kwargs) -> tuple[int, int, list[DialogueExchange]]:
    """n회 반복. 반환: (clean_count, n, exchanges)"""
    exchanges = []
    clean = 0
    for i in range(1, n + 1):
        ex = run_dialogue(**kwargs)
        exchanges.append(ex)
        if ex.is_clean and ex.turns:
            clean += 1
        log.info("[%d/%d] clean=%s temp=%s", i, n, ex.is_clean, ex.temperature_c)
    return clean, n, exchanges


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    p = argparse.ArgumentParser(description="Qwen <-> Llama3.3 영어 발화 릴레이")
    p.add_argument("--device", "-d", type=int, default=0)
    p.add_argument("--threshold", type=float, default=DEFAULT_TEMP_THRESHOLD_C)
    p.add_argument("-n", "--count", type=int, default=1)
    p.add_argument("--save", type=str, default=None, help="결과를 저장할 .jsonl 경로")
    args = p.parse_args()

    if args.count <= 1:
        ex = run_dialogue(device_index=args.device, threshold_c=args.threshold)
        print(ex.summary())
        if args.save:
            with open(args.save, "w", encoding="utf-8") as f:
                f.write(json.dumps(ex.to_dict(), ensure_ascii=False) + "\n")
    else:
        clean, n, exchanges = run_dialogue_batch(
            args.count, device_index=args.device, threshold_c=args.threshold
        )
        print(f"\n=== {n}회 중 CLEAN(환각/에러 없음): {clean}회 ({100.0*clean/n:.1f}%) ===")
        if args.save:
            with open(args.save, "w", encoding="utf-8") as f:
                for ex in exchanges:
                    f.write(json.dumps(ex.to_dict(), ensure_ascii=False) + "\n")
            print(f"[저장] {args.save}")
